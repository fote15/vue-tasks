import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  CompletedButton: () => import('../..\\components\\CompletedButton.vue' /* webpackChunkName: "components/completed-button" */).then(c => wrapFunctional(c.default || c)),
  CompleteMessage: () => import('../..\\components\\CompleteMessage.vue' /* webpackChunkName: "components/complete-message" */).then(c => wrapFunctional(c.default || c)),
  Header: () => import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c)),
  Task: () => import('../..\\components\\Task.vue' /* webpackChunkName: "components/task" */).then(c => wrapFunctional(c.default || c)),
  UserCheck: () => import('../..\\components\\UserCheck.vue' /* webpackChunkName: "components/user-check" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
