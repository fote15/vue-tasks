import { wrapFunctional } from './utils'

export { default as CompletedButton } from '../..\\components\\CompletedButton.vue'
export { default as CompleteMessage } from '../..\\components\\CompleteMessage.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as Task } from '../..\\components\\Task.vue'
export { default as UserCheck } from '../..\\components\\UserCheck.vue'

export const LazyCompletedButton = import('../..\\components\\CompletedButton.vue' /* webpackChunkName: "components/completed-button" */).then(c => wrapFunctional(c.default || c))
export const LazyCompleteMessage = import('../..\\components\\CompleteMessage.vue' /* webpackChunkName: "components/complete-message" */).then(c => wrapFunctional(c.default || c))
export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const LazyTask = import('../..\\components\\Task.vue' /* webpackChunkName: "components/task" */).then(c => wrapFunctional(c.default || c))
export const LazyUserCheck = import('../..\\components\\UserCheck.vue' /* webpackChunkName: "components/user-check" */).then(c => wrapFunctional(c.default || c))
