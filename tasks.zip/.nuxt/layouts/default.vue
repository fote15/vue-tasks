<template>
  <div class="container">
    <Header />
    <div class="bg-white py-2 px-3">
      <Nuxt />
    </div>
  </div>
</template>
<script>
export default {
  head: {
    bodyAttrs: {
      class: "bg-blue-200",
    },
  },
};
</script>