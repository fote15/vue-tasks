<template>
  <header class="header">
    <ul class="flex">
      <li class="mr-3">
        <nuxt-link class="my-2 inline-block border border-blue-500 rounded py-1 px-3 bg-blue-500 text-white" to="/">
          Home
        </nuxt-link>
      </li>
    </ul>
  </header>
</template>

<script>
export default {}
</script>

<style scoped>
</style>
